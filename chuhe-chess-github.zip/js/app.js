/*
 * 楚河棋局 · 页面交互
 */
(function () {
  'use strict';

  const X = window.Xiangqi;
  if (!X) {
    throw new Error('请先加载象棋规则引擎');
  }

  const {
    Game,
    ROWS,
    COLS,
    RED,
    BLACK,
    PIECE_NAMES,
    colorName,
    pieceName,
    opposite
  } = X;

  const els = {
    boardArt: document.getElementById('boardArt'),
    board: document.getElementById('board'),
    boardFrame: document.getElementById('boardFrame'),
    cells: document.getElementById('cells'),
    redStrip: document.getElementById('redStrip'),
    blackStrip: document.getElementById('blackStrip'),
    redCaptured: document.getElementById('redCaptured'),
    blackCaptured: document.getElementById('blackCaptured'),
    statusCard: document.getElementById('statusCard'),
    statusSeal: document.getElementById('statusSeal'),
    turnTitle: document.getElementById('turnTitle'),
    turnHint: document.getElementById('turnHint'),
    statusDetail: document.getElementById('statusDetail'),
    liveLabel: document.getElementById('liveLabel'),
    moveCount: document.getElementById('moveCount'),
    moveList: document.getElementById('moveList'),
    historyEmpty: document.getElementById('historyEmpty'),
    historyScroll: document.getElementById('historyScroll'),
    undoBtn: document.getElementById('undoBtn'),
    newGameBtn: document.getElementById('newGameBtn'),
    soundToggle: document.getElementById('soundToggle'),
    rulesBtn: document.getElementById('rulesBtn'),
    rulesDialog: document.getElementById('rulesDialog'),
    confirmDialog: document.getElementById('confirmDialog'),
    confirmCancel: document.getElementById('confirmCancel'),
    confirmRestart: document.getElementById('confirmRestart'),
    resultDialog: document.getElementById('resultDialog'),
    resultSeal: document.getElementById('resultSeal'),
    resultTitle: document.getElementById('resultTitle'),
    resultReason: document.getElementById('resultReason'),
    resultMoves: document.getElementById('resultMoves'),
    resultCaptures: document.getElementById('resultCaptures'),
    resultNew: document.getElementById('resultNew'),
    resultReview: document.getElementById('resultReview'),
    liveRegion: document.getElementById('liveRegion')
  };

  const state = {
    game: new Game(),
    selected: null,
    legalMoves: [],
    renderedHistoryLength: 0,
    roving: { row: 9, col: 4 },
    restoreFocus: null,
    notice: null,
    noticeTimer: 0,
    resultTimer: 0,
    announceTimer: 0,
    soundOn: true,
    audioContext: null
  };

  try {
    if (window.localStorage.getItem('chuhe-sound') === 'off') {
      state.soundOn = false;
    }
  } catch (error) {
    /* 本地文件或隐私模式下可能无法读取 localStorage，忽略即可。 */
  }

  /* ==========================================================
     棋盘纹样
     ========================================================== */

  function buildBoardArt() {
    const marks = [];
    const x = function (col) { return 50 + col * 100; };
    const y = function (row) { return 50 + row * 100; };

    marks.push('<rect class="board-border" x="32" y="32" width="836" height="936" rx="1"/>');

    for (let row = 0; row < ROWS; row += 1) {
      marks.push('<line class="board-line" x1="50" y1="' + y(row) + '" x2="850" y2="' + y(row) + '"/>');
    }

    for (let col = 0; col < COLS; col += 1) {
      const px = x(col);
      if (col === 0 || col === COLS - 1) {
        marks.push('<line class="board-line" x1="' + px + '" y1="50" x2="' + px + '" y2="950"/>');
      } else {
        marks.push('<line class="board-line" x1="' + px + '" y1="50" x2="' + px + '" y2="450"/>');
        marks.push('<line class="board-line" x1="' + px + '" y1="550" x2="' + px + '" y2="950"/>');
      }
    }

    // 双方九宫斜线
    marks.push('<line class="palace-line" x1="350" y1="50" x2="550" y2="250"/>');
    marks.push('<line class="palace-line" x1="550" y1="50" x2="350" y2="250"/>');
    marks.push('<line class="palace-line" x1="350" y1="750" x2="550" y2="950"/>');
    marks.push('<line class="palace-line" x1="550" y1="750" x2="350" y2="950"/>');

    // 炮位与兵位的传统角标
    const markPoints = [];
    [0, 2, 4, 6, 8].forEach(function (col) {
      markPoints.push([3, col]);
      markPoints.push([6, col]);
    });
    [[2, 1], [2, 7], [7, 1], [7, 7]].forEach(function (point) {
      markPoints.push(point);
    });

    markPoints.forEach(function (point) {
      const px = x(point[1]);
      const py = y(point[0]);
      [-1, 1].forEach(function (sx) {
        [-1, 1].forEach(function (sy) {
          const cornerX = px + sx * 9;
          const cornerY = py + sy * 9;
          marks.push(
            '<path class="mark-line" d="M ' + cornerX + ' ' + (cornerY + sy * 7) +
            ' L ' + cornerX + ' ' + cornerY +
            ' L ' + (cornerX + sx * 7) + ' ' + cornerY + '"/>'
          );
        });
      });
    });

    els.boardArt.innerHTML = '<g>' + marks.join('') + '</g>';
  }

  /* ==========================================================
     渲染
     ========================================================== */

  function keyOf(row, col) {
    return row + ',' + col;
  }

  function render() {
    const previousLength = state.renderedHistoryLength;
    const isNewMove = previousLength !== null &&
      state.game.history.length === previousLength + 1;

    renderBoard(isNewMove);
    renderPlayers();
    renderStatus();
    renderHistory(isNewMove);
    els.undoBtn.disabled = state.game.history.length === 0;
    state.renderedHistoryLength = state.game.history.length;

    if (state.restoreFocus) {
      const focus = state.restoreFocus;
      state.restoreFocus = null;
      focusBoardCell(focus.row, focus.col);
    }
  }

  function renderBoard(isNewMove) {
    const game = state.game;
    const selected = state.selected;
    const selectedKey = selected ? keyOf(selected.row, selected.col) : '';
    const targets = new Set(state.legalMoves.map(function (move) {
      return keyOf(move.row, move.col);
    }));
    const lastMove = game.lastMove;
    const lastFrom = lastMove ? keyOf(lastMove.from.row, lastMove.from.col) : '';
    const lastTo = lastMove ? keyOf(lastMove.to.row, lastMove.to.col) : '';
    const highlightGeneral = game.check && game.status !== 'capture'
      ? game.findGeneral(game.turn)
      : null;

    const fragment = document.createDocumentFragment();

    for (let row = 0; row < ROWS; row += 1) {
      for (let col = 0; col < COLS; col += 1) {
        const piece = game.get(row, col);
        const cellKey = keyOf(row, col);
        const isSelected = Boolean(selected && selected.row === row && selected.col === col);
        const isTarget = targets.has(cellKey);
        const playable = Boolean(piece && piece.color === game.turn && game.status === 'playing');

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'cell';
        button.dataset.row = String(row);
        button.dataset.col = String(col);
        button.style.left = (((col + 0.5) / COLS) * 100) + '%';
        button.style.top = (((row + 0.5) / ROWS) * 100) + '%';
        button.tabIndex = -1;

        if (piece) button.classList.add('has-piece');
        if (playable) button.classList.add('is-playable');
        if (isSelected) button.classList.add('selected');
        if (isTarget) button.classList.add('is-target');
        if (lastFrom === cellKey) button.classList.add('last-from');
        if (lastTo === cellKey) button.classList.add('last-to');
        if (isNewMove && lastTo === cellKey) button.classList.add('just-landed');
        if (highlightGeneral && highlightGeneral.row === row && highlightGeneral.col === col) {
          button.classList.add('general-in-check');
        }

        if (piece) {
          const pieceEl = document.createElement('span');
          pieceEl.className = 'piece ' + piece.color;
          pieceEl.setAttribute('aria-hidden', 'true');
          const glyph = document.createElement('span');
          glyph.className = 'piece-glyph';
          glyph.textContent = PIECE_NAMES[piece.color][piece.type];
          pieceEl.appendChild(glyph);
          button.appendChild(pieceEl);
        }

        if (isTarget) {
          const marker = document.createElement('span');
          marker.className = 'marker ' + (piece ? 'capture' : 'move');
          marker.setAttribute('aria-hidden', 'true');
          button.appendChild(marker);
        }

        let label = '空位，第 ' + (row + 1) + ' 行第 ' + (col + 1) + ' 列';
        if (piece) {
          label = colorName(piece.color) + pieceName(piece) + '，第 ' + (row + 1) + ' 行第 ' + (col + 1) + ' 列';
          if (isSelected) {
            label += '，已选中';
          } else if (isTarget) {
            label += '，可以吃子';
          } else if (playable) {
            label += '，点击选中';
          } else if (game.status !== 'playing') {
            label += '，对局已结束';
          }
        } else if (isTarget) {
          label += '，可以落子';
        }
        button.setAttribute('aria-label', label);
        if (isSelected) button.setAttribute('aria-pressed', 'true');

        fragment.appendChild(button);
      }
    }

    els.cells.replaceChildren(fragment);
    syncTabindex();
  }

  function renderPlayers() {
    const game = state.game;
    const captured = { red: [], black: [] };
    game.history.forEach(function (move) {
      if (move.captured) captured[move.color].push(move.captured);
    });

    renderCaptured(els.redCaptured, captured.red, RED);
    renderCaptured(els.blackCaptured, captured.black, BLACK);

    updateStrip(els.redStrip, RED, captured.red);
    updateStrip(els.blackStrip, BLACK, captured.black);
  }

  function renderCaptured(container, pieces, side) {
    const fragment = document.createDocumentFragment();
    const names = [];
    pieces.forEach(function (piece) {
      names.push(colorName(piece.color) + pieceName(piece));
      const token = document.createElement('span');
      token.className = 'captured-piece ' + piece.color;
      token.textContent = PIECE_NAMES[piece.color][piece.type];
      token.title = colorName(piece.color) + pieceName(piece);
      token.setAttribute('aria-hidden', 'true');
      fragment.appendChild(token);
    });
    container.replaceChildren(fragment);
    container.setAttribute(
      'aria-label',
      names.length ? colorName(side) + '已吃：' + names.join('、') : colorName(side) + '暂未吃子'
    );
    container.title = names.length ? names.join('、') : '';
  }

  function updateStrip(strip, side, captured) {
    const game = state.game;
    const isActive = game.status === 'playing' && game.turn === side;
    const isCheck = game.check && game.turn === side;
    const isWinner = game.winner === side;
    strip.classList.toggle('active', isActive);
    strip.classList.toggle('is-check', isCheck);
    strip.classList.toggle('winner', isWinner);

    const flagText = strip.querySelector('.flag-text');
    if (flagText) {
      if (isWinner) flagText.textContent = '胜';
      else if (isActive && isCheck) flagText.textContent = '应将';
      else flagText.textContent = '行棋中';
    }

    strip.setAttribute(
      'aria-label',
      colorName(side) + (isWinner ? '，胜' : isActive ? '，行棋中' : '') +
      '，已吃' + captured.length + '子'
    );
  }

  function renderStatus() {
    const game = state.game;
    const classes = ['is-red', 'is-black', 'is-check', 'is-over'];
    els.statusCard.classList.remove.apply(els.statusCard.classList, classes);
    els.boardFrame.classList.toggle('is-check', game.check && game.status !== 'capture');
    els.liveLabel.textContent = game.status === 'playing' ? 'LIVE' : 'END';

    if (game.status === 'playing') {
      const side = game.turn;
      const inCheck = game.check;
      const selectedPiece = state.selected ? game.get(state.selected.row, state.selected.col) : null;
      const round = Math.floor(game.history.length / 2) + 1;

      els.statusCard.classList.add(side === RED ? 'is-red' : 'is-black');
      if (inCheck) els.statusCard.classList.add('is-check');
      els.statusSeal.textContent = PIECE_NAMES[side].K;

      if (inCheck) {
        els.turnTitle.textContent = colorName(side) + '被将军';
      } else {
        els.turnTitle.textContent = colorName(side) + '行棋';
      }

      if (state.notice && !inCheck) {
        els.turnHint.textContent = state.notice;
      } else if (inCheck) {
        els.turnHint.textContent = '请立即应将，化解攻势';
      } else if (selectedPiece) {
        const count = state.legalMoves.length;
        els.turnHint.textContent = count > 0
          ? '已选' + pieceName(selectedPiece) + ' · ' + count + ' 个合法落点'
          : '这枚' + pieceName(selectedPiece) + '暂无合法落点';
      } else {
        els.turnHint.textContent = '点击棋子，查看可行落点';
      }

      els.statusDetail.textContent = '第 ' + round + ' 回合 · ' +
        (inCheck ? colorName(side) + '应将' : (game.history.length === 0 ? '红方先行' : colorName(side) + '行棋'));

      document.title = colorName(side) + (inCheck ? '应将' : '行棋') + ' · 楚河棋局';
      return;
    }

    els.statusCard.classList.add('is-over');
    if (game.check) els.statusCard.classList.add('is-check');
    const winner = game.winner;
    const loser = winner ? opposite(winner) : game.turn;
    els.statusSeal.textContent = '胜';
    els.turnTitle.textContent = winner ? colorName(winner) + '胜' : '对局结束';

    let hint = '对局结束';
    if (game.endReason === 'checkmate') {
      hint = '绝杀 · ' + colorName(loser) + '无子可解';
    } else if (game.endReason === 'stalemate') {
      hint = '困毙 · ' + colorName(loser) + '无子可走';
    } else if (game.endReason === 'capture') {
      hint = '擒王 · ' + colorName(loser) + '主帅被擒';
    }
    els.turnHint.textContent = hint;
    els.statusDetail.textContent = '共 ' + game.history.length + ' 手 · 对局结束';
    document.title = (winner ? colorName(winner) + '胜' : '对局结束') + ' · 楚河棋局';
  }

  function renderHistory(scrollToBottom) {
    const game = state.game;
    els.moveCount.textContent = game.history.length + ' 手';

    if (game.history.length === 0) {
      els.historyEmpty.hidden = false;
      els.moveList.hidden = true;
      els.moveList.replaceChildren();
      return;
    }

    els.historyEmpty.hidden = true;
    els.moveList.hidden = false;

    const fragment = document.createDocumentFragment();
    const lastIndex = game.history.length - 1;

    for (let index = 0; index < game.history.length; index += 2) {
      const redMove = game.history[index];
      const blackMove = game.history[index + 1];
      const row = document.createElement('li');
      row.className = 'move-row';

      const number = document.createElement('span');
      number.className = 'move-no';
      number.textContent = (index / 2 + 1) + '.';
      row.appendChild(number);
      row.appendChild(buildMoveChip(redMove, RED, index, lastIndex));
      row.appendChild(buildMoveChip(blackMove, BLACK, index + 1, lastIndex));
      fragment.appendChild(row);
    }

    els.moveList.replaceChildren(fragment);

    if (scrollToBottom) {
      window.requestAnimationFrame(function () {
        els.historyScroll.scrollTop = els.historyScroll.scrollHeight;
      });
    }
  }

  function buildMoveChip(move, color, index, lastIndex) {
    const chip = document.createElement('span');
    chip.className = 'move-chip ' + color;

    if (!move) {
      chip.classList.add('empty');
      chip.textContent = '—';
      chip.setAttribute('aria-hidden', 'true');
      return chip;
    }

    chip.textContent = move.notation;
    chip.title = colorName(color) + ' ' + move.notation;
    if (index === lastIndex) chip.classList.add('current');

    let suffix = '';
    if (move.endReason === 'checkmate') suffix = '绝杀';
    else if (move.endReason === 'stalemate') suffix = '困毙';
    else if (move.endReason === 'capture') suffix = '擒王';
    else if (move.gaveCheck) suffix = '将';

    if (suffix) {
      const badge = document.createElement('span');
      badge.className = 'move-suffix';
      badge.textContent = suffix;
      chip.appendChild(badge);
    }

    return chip;
  }

  /* ==========================================================
     选子与落子
     ========================================================== */

  function selectPiece(row, col) {
    const game = state.game;
    const piece = game.get(row, col);
    if (!piece || piece.color !== game.turn || game.status !== 'playing') return;

    state.selected = { row: row, col: col };
    state.legalMoves = game.getLegalMovesFrom(row, col);
    state.notice = null;
    state.roving = { row: row, col: col };
    state.restoreFocus = { row: row, col: col };
    window.clearTimeout(state.noticeTimer);
    render();
    announce(colorName(piece.color) + pieceName(piece) + '，' +
      state.legalMoves.length + ' 个合法落点');
  }

  function clearSelection(focusRow, focusCol) {
    state.selected = null;
    state.legalMoves = [];
    if (typeof focusRow === 'number') {
      state.roving = { row: focusRow, col: focusCol };
      state.restoreFocus = { row: focusRow, col: focusCol };
    }
  }

  function performCellAction(row, col) {
    const game = state.game;
    if (game.status !== 'playing') return;

    const piece = game.get(row, col);
    const selected = state.selected;

    if (selected) {
      if (selected.row === row && selected.col === col) {
        clearSelection(row, col);
        render();
        return;
      }

      const target = state.legalMoves.some(function (move) {
        return move.row === row && move.col === col;
      });

      if (target) {
        commitMove(selected.row, selected.col, row, col);
        return;
      }

      if (piece && piece.color === game.turn) {
        selectPiece(row, col);
        return;
      }

      clearSelection(row, col);
      render();
      if (piece && piece.color !== game.turn) {
        setNotice('现在轮到' + colorName(game.turn));
      }
      return;
    }

    if (piece && piece.color === game.turn) {
      selectPiece(row, col);
      return;
    }

    if (piece) {
      setNotice('现在轮到' + colorName(game.turn));
    }
  }

  function commitMove(fromRow, fromCol, toRow, toCol) {
    const game = state.game;
    let record;

    try {
      record = game.makeMove(fromRow, fromCol, toRow, toCol);
    } catch (error) {
      setNotice('这一步不能走');
      return;
    }

    state.selected = null;
    state.legalMoves = [];
    state.notice = null;
    state.roving = { row: toRow, col: toCol };
    state.restoreFocus = { row: toRow, col: toCol };
    window.clearTimeout(state.noticeTimer);

    render();

    if (record.endReason) {
      playEndSound(record.endReason);
      window.clearTimeout(state.resultTimer);
      state.resultTimer = window.setTimeout(function () {
        openResult();
      }, 480);
      const loser = opposite(game.winner);
      if (record.endReason === 'checkmate') {
        announce(colorName(game.winner) + '绝杀' + colorName(loser) + '，对局结束');
      } else if (record.endReason === 'stalemate') {
        announce(colorName(loser) + '困毙，' + colorName(game.winner) + '获胜');
      } else {
        announce(colorName(game.winner) + '擒获主帅，对局结束');
      }
      return;
    }

    playMoveSound(record);
    announce(colorName(record.color) + record.notation + (record.gaveCheck ? '，将军' : ''));
  }

  function setNotice(text) {
    state.notice = text;
    window.clearTimeout(state.noticeTimer);
    renderStatus();
    state.noticeTimer = window.setTimeout(function () {
      state.notice = null;
      renderStatus();
    }, 1800);
  }

  function undoMove() {
    if (state.game.history.length === 0) return;
    if (document.querySelector('dialog[open]')) return;

    window.clearTimeout(state.resultTimer);
    const record = state.game.undo();
    state.selected = null;
    state.legalMoves = [];
    state.notice = null;
    state.roving = record
      ? { row: record.from.row, col: record.from.col }
      : { row: 9, col: 4 };
    state.restoreFocus = state.roving;
    render();
    playUndoSound();
    announce('已悔棋，轮到' + colorName(state.game.turn) + '行棋');
  }

  function startNewGame() {
    document.querySelectorAll('dialog[open]').forEach(function (dialog) {
      dialog.close();
    });
    window.clearTimeout(state.resultTimer);
    window.clearTimeout(state.noticeTimer);
    state.resultTimer = 0;
    state.notice = null;
    state.game = new Game();
    state.selected = null;
    state.legalMoves = [];
    state.renderedHistoryLength = 0;
    state.roving = { row: 9, col: 4 };
    state.restoreFocus = null;
    els.historyScroll.scrollTop = 0;
    render();
    announce('新对局开始，红方先行');
  }

  function requestNewGame() {
    if (state.game.history.length === 0 || state.game.status !== 'playing') {
      startNewGame();
      return;
    }
    if (!els.confirmDialog.open) {
      els.confirmDialog.showModal();
      syncModalState();
    }
  }

  function openResult() {
    const game = state.game;
    if (!game.winner || game.status === 'playing') return;

    const winner = game.winner;
    const loser = opposite(winner);
    let reason = '';
    if (game.endReason === 'checkmate') {
      reason = '绝杀 · ' + colorName(loser) + '无子可解';
    } else if (game.endReason === 'stalemate') {
      reason = '困毙 · ' + colorName(loser) + '无子可走';
    } else {
      reason = '擒王 · ' + colorName(loser) + '主帅被擒';
    }

    els.resultSeal.textContent = '胜';
    els.resultSeal.classList.toggle('black', winner === BLACK);
    els.resultTitle.textContent = colorName(winner) + '胜';
    els.resultReason.textContent = reason;
    els.resultMoves.textContent = String(game.history.length);
    els.resultCaptures.textContent = String(game.history.reduce(function (count, move) {
      return count + (move.captured ? 1 : 0);
    }, 0));

    document.querySelectorAll('dialog[open]').forEach(function (dialog) {
      if (dialog !== els.resultDialog) dialog.close();
    });
    if (!els.resultDialog.open) {
      els.resultDialog.showModal();
      syncModalState();
    }
  }

  /* ==========================================================
     键盘焦点
     ========================================================== */

  function syncTabindex() {
    const cells = els.cells.querySelectorAll('.cell');
    let active = null;
    cells.forEach(function (cell) {
      const row = Number(cell.dataset.row);
      const col = Number(cell.dataset.col);
      const isRoving = row === state.roving.row && col === state.roving.col;
      cell.tabIndex = isRoving ? 0 : -1;
      if (isRoving) active = cell;
    });

    if (!active && cells.length) {
      const general = state.game.findGeneral(state.game.turn);
      const fallback = general || { row: 9, col: 4 };
      state.roving = { row: fallback.row, col: fallback.col };
      const cell = getCell(fallback.row, fallback.col);
      if (cell) cell.tabIndex = 0;
    }
  }

  function getCell(row, col) {
    return els.cells.querySelector('.cell[data-row="' + row + '"][data-col="' + col + '"]');
  }

  function focusBoardCell(row, col) {
    const cell = getCell(row, col);
    if (!cell) return;
    state.roving = { row: row, col: col };
    syncTabindex();
    try {
      cell.focus({ preventScroll: true });
    } catch (error) {
      cell.focus();
    }
  }

  function setupKeyboard() {
    els.cells.addEventListener('keydown', function (event) {
      const cell = event.target.closest('.cell');
      if (!cell) return;
      if (event.altKey || event.ctrlKey || event.metaKey) return;

      const row = Number(cell.dataset.row);
      const col = Number(cell.dataset.col);
      let nextRow = row;
      let nextCol = col;

      if (event.key === 'ArrowUp') nextRow = Math.max(0, row - 1);
      else if (event.key === 'ArrowDown') nextRow = Math.min(ROWS - 1, row + 1);
      else if (event.key === 'ArrowLeft') nextCol = Math.max(0, col - 1);
      else if (event.key === 'ArrowRight') nextCol = Math.min(COLS - 1, col + 1);
      else if (event.key === 'Home') nextCol = 0;
      else if (event.key === 'End') nextCol = COLS - 1;
      else if (event.key === 'Escape') {
        if (state.selected) {
          clearSelection(row, col);
          render();
        }
        return;
      } else {
        return;
      }

      event.preventDefault();
      focusBoardCell(nextRow, nextCol);
    });

    els.cells.addEventListener('focusin', function (event) {
      const cell = event.target.closest('.cell');
      if (!cell) return;
      state.roving = { row: Number(cell.dataset.row), col: Number(cell.dataset.col) };
      syncTabindex();
    });
  }

  /* ==========================================================
     音效
     ========================================================== */

  function getAudioContext() {
    if (!state.soundOn) return null;
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    if (!state.audioContext) {
      try {
        state.audioContext = new AudioCtx();
      } catch (error) {
        return null;
      }
    }
    if (state.audioContext.state === 'suspended') {
      state.audioContext.resume().catch(function () {});
    }
    return state.audioContext;
  }

  function tone(frequency, duration, options) {
    const ctx = getAudioContext();
    if (!ctx) return;
    options = options || {};
    const start = ctx.currentTime + (options.delay || 0);
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();

    oscillator.type = options.type || 'sine';
    oscillator.frequency.setValueAtTime(frequency, start);
    if (options.endFrequency) {
      oscillator.frequency.exponentialRampToValueAtTime(options.endFrequency, start + duration);
    }

    const volume = options.volume || 0.035;
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.linearRampToValueAtTime(volume, start + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);

    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.03);
  }

  function playMoveSound(record) {
    if (!state.soundOn) return;
    tone(205, 0.055, { type: 'triangle', volume: 0.042, endFrequency: 150 });
    tone(760, 0.022, { type: 'sine', volume: 0.009, delay: 0.006 });
    if (record.captured) {
      tone(120, 0.11, { type: 'triangle', volume: 0.055, endFrequency: 82, delay: 0.01 });
      tone(340, 0.045, { type: 'square', volume: 0.012, delay: 0.02 });
    }
    if (record.gaveCheck) {
      tone(880, 0.2, { type: 'sine', volume: 0.026, delay: 0.09 });
      tone(1174, 0.32, { type: 'sine', volume: 0.022, delay: 0.18 });
    }
  }

  function playEndSound(reason) {
    if (!state.soundOn) return;
    if (reason === 'stalemate') {
      tone(392, 0.4, { type: 'sine', volume: 0.028 });
      tone(329, 0.55, { type: 'sine', volume: 0.024, delay: 0.16 });
    } else {
      tone(523, 0.3, { type: 'sine', volume: 0.03 });
      tone(659, 0.34, { type: 'sine', volume: 0.03, delay: 0.1 });
      tone(784, 0.4, { type: 'sine', volume: 0.03, delay: 0.21 });
      tone(1046, 0.7, { type: 'sine', volume: 0.024, delay: 0.34 });
    }
  }

  function playUndoSound() {
    if (!state.soundOn) return;
    tone(340, 0.06, { type: 'triangle', volume: 0.022, endFrequency: 250 });
  }

  function setSound(on, playPreview) {
    state.soundOn = on;
    els.soundToggle.classList.toggle('sound-off', !on);
    els.soundToggle.setAttribute('aria-pressed', String(on));
    els.soundToggle.setAttribute('aria-label', on ? '关闭音效' : '开启音效');
    try {
      window.localStorage.setItem('chuhe-sound', on ? 'on' : 'off');
    } catch (error) {
      /* 忽略无法写入本地存储的情况。 */
    }
    if (on && playPreview) {
      tone(660, 0.08, { type: 'sine', volume: 0.018 });
    }
  }

  /* ==========================================================
     对话框
     ========================================================== */

  function syncModalState() {
    const hasOpenDialog = Boolean(document.querySelector('dialog[open]'));
    document.body.classList.toggle('modal-open', hasOpenDialog);
  }

  function setupDialogs() {
    document.querySelectorAll('[data-close]').forEach(function (button) {
      button.addEventListener('click', function () {
        const dialog = button.closest('dialog');
        if (dialog) dialog.close();
        syncModalState();
      });
    });

    document.querySelectorAll('dialog').forEach(function (dialog) {
      dialog.addEventListener('close', syncModalState);
      dialog.addEventListener('click', function (event) {
        if (event.target === dialog) {
          dialog.close();
          syncModalState();
        }
      });
    });

    if (typeof document.addEventListener === 'function') {
      document.addEventListener('toggle', function (event) {
        if (event.target && event.target.tagName === 'DIALOG') {
          syncModalState();
        }
      }, true);
    }

    els.rulesBtn.addEventListener('click', function () {
      if (!els.rulesDialog.open) {
        els.rulesDialog.showModal();
        syncModalState();
      }
    });

    els.confirmCancel.addEventListener('click', function () {
      els.confirmDialog.close();
      syncModalState();
    });

    els.confirmRestart.addEventListener('click', function () {
      els.confirmDialog.close();
      syncModalState();
      startNewGame();
    });

    els.resultNew.addEventListener('click', function () {
      els.resultDialog.close();
      syncModalState();
      startNewGame();
    });

    els.resultReview.addEventListener('click', function () {
      els.resultDialog.close();
      syncModalState();
    });
  }

  /* ==========================================================
     通知与事件绑定
     ========================================================== */

  function announce(text) {
    window.clearTimeout(state.announceTimer);
    els.liveRegion.textContent = '';
    state.announceTimer = window.setTimeout(function () {
      els.liveRegion.textContent = text;
    }, 35);
  }

  function setupEvents() {
    els.cells.addEventListener('click', function (event) {
      const cell = event.target.closest('.cell');
      if (!cell) return;
      const row = Number(cell.dataset.row);
      const col = Number(cell.dataset.col);
      state.roving = { row: row, col: col };
      state.restoreFocus = { row: row, col: col };
      performCellAction(row, col);
    });

    setupKeyboard();

    els.undoBtn.addEventListener('click', undoMove);
    els.newGameBtn.addEventListener('click', requestNewGame);
    els.soundToggle.addEventListener('click', function () {
      setSound(!state.soundOn, true);
    });

    document.addEventListener('keydown', function (event) {
      if ((event.ctrlKey || event.metaKey) && !event.shiftKey && event.key.toLowerCase() === 'z') {
        if (document.querySelector('dialog[open]')) return;
        event.preventDefault();
        undoMove();
      }
    });
  }

  /* ==========================================================
     启动
     ========================================================== */

  function init() {
    buildBoardArt();
    setupEvents();
    setupDialogs();
    setSound(state.soundOn, false);
    render();
  }

  init();
})();
