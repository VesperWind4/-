/*
 * 楚河棋局 · 中国象棋规则引擎
 * ------------------------------------------------------------
 * 棋盘坐标：10 行 × 9 列，row 0 在棋盘上方（黑方底线），
 * row 9 在棋盘下方（红方底线）。红方向上走，黑方向下走。
 *
 * 这个文件不依赖 DOM，可以直接在 Node.js 中测试。
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.Xiangqi = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const ROWS = 10;
  const COLS = 9;
  const RED = 'red';
  const BLACK = 'black';

  const START_POSITION = [
    'rheakaehr',
    '.........',
    '.c.....c.',
    'p.p.p.p.p',
    '.........',
    '.........',
    'P.P.P.P.P',
    '.C.....C.',
    '.........',
    'RHEAKAEHR'
  ];

  const PIECE_NAMES = {
    red: { K: '帅', A: '仕', E: '相', H: '马', R: '车', C: '炮', P: '兵' },
    black: { K: '将', A: '士', E: '象', H: '马', R: '车', C: '炮', P: '卒' }
  };

  const PIECE_TITLES = {
    K: '将帅',
    A: '士仕',
    E: '象相',
    H: '马',
    R: '车',
    C: '炮',
    P: '兵卒'
  };

  const CHINESE_NUMERALS = ['一', '二', '三', '四', '五', '六', '七', '八', '九'];
  const ORTHOGONAL = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  const DIAGONAL = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  const HORSE_MOVES = [
    [-2, -1, -1, 0], [-2, 1, -1, 0],
    [-1, -2, 0, -1], [-1, 2, 0, 1],
    [1, -2, 0, -1], [1, 2, 0, 1],
    [2, -1, 1, 0], [2, 1, 1, 0]
  ];
  const ELEPHANT_MOVES = [[-2, -2], [-2, 2], [2, -2], [2, 2]];
  const VALID_TYPES = new Set(['K', 'A', 'E', 'H', 'R', 'C', 'P']);

  function opposite(color) {
    return color === RED ? BLACK : RED;
  }

  function inBounds(row, col) {
    return row >= 0 && row < ROWS && col >= 0 && col < COLS;
  }

  function inPalace(color, row, col) {
    if (col < 3 || col > 5) return false;
    return color === RED ? row >= 7 && row <= 9 : row >= 0 && row <= 2;
  }

  function pieceName(piece) {
    if (!piece) return '';
    return PIECE_NAMES[piece.color][piece.type] || '';
  }

  function colorName(color) {
    return color === RED ? '红方' : '黑方';
  }

  function clonePosition(position) {
    return position.map(function (row) { return String(row); });
  }

  class Game {
    constructor(options) {
      options = options || {};
      const position = options.position || START_POSITION;
      const turn = options.turn || RED;

      if (!Array.isArray(position) || position.length !== ROWS) {
        throw new Error('棋盘必须是 10 行');
      }
      if (turn !== RED && turn !== BLACK) {
        throw new Error('未知的行棋方');
      }

      this.initialPosition = clonePosition(position);
      this.initialTurn = turn;
      this._setup();
    }

    _setup() {
      this._nextPieceId = 1;
      this.board = this._parsePosition(this.initialPosition);
      this.turn = this.initialTurn;
      this.history = [];
      this.lastMove = null;
      this.status = 'playing';
      this.winner = null;
      this.endReason = null;
      this.check = false;
      this.check = this.isInCheck(this.turn);
      this.refreshStatus();
    }

    reset() {
      this._setup();
      return this;
    }

    _parsePosition(position) {
      const board = [];
      for (let row = 0; row < ROWS; row += 1) {
        const line = String(position[row] || '');
        if (line.length !== COLS) {
          throw new Error('第 ' + (row + 1) + ' 行必须有 9 列');
        }
        const boardRow = [];
        for (let col = 0; col < COLS; col += 1) {
          const symbol = line[col];
          if (symbol === '.') {
            boardRow.push(null);
            continue;
          }
          const type = symbol.toUpperCase();
          if (!VALID_TYPES.has(type)) {
            throw new Error('未知棋子：' + symbol);
          }
          boardRow.push({
            id: this._nextPieceId++,
            type: type,
            color: symbol === type ? RED : BLACK
          });
        }
        board.push(boardRow);
      }
      return board;
    }

    get(row, col) {
      if (!inBounds(row, col)) return null;
      return this.board[row][col];
    }

    isOver() {
      return this.status !== 'playing';
    }

    findGeneral(color) {
      for (let row = 0; row < ROWS; row += 1) {
        for (let col = 0; col < COLS; col += 1) {
          const piece = this.board[row][col];
          if (piece && piece.type === 'K' && piece.color === color) {
            return { row: row, col: col, piece: piece };
          }
        }
      }
      return null;
    }

    /* 两格之间是否没有棋子（只支持同一行或同一列）。 */
    _clearBetween(rowA, colA, rowB, colB) {
      if (rowA === rowB) {
        const from = Math.min(colA, colB) + 1;
        const to = Math.max(colA, colB);
        for (let col = from; col < to; col += 1) {
          if (this.board[rowA][col]) return false;
        }
        return true;
      }
      if (colA === colB) {
        const from = Math.min(rowA, rowB) + 1;
        const to = Math.max(rowA, rowB);
        for (let row = from; row < to; row += 1) {
          if (this.board[row][colA]) return false;
        }
        return true;
      }
      return false;
    }

    /*
     * 生成不考虑“己方被将军”的走法。
     * 这里仍然会过滤掉吃己方棋子的落点。
     */
    _pseudoMovesFrom(row, col) {
      const piece = this.get(row, col);
      if (!piece) return [];
      const moves = [];
      const color = piece.color;

      const add = function (nextRow, nextCol) {
        if (!inBounds(nextRow, nextCol)) return;
        const target = this.board[nextRow][nextCol];
        if (target && target.color === color) return;
        moves.push({ row: nextRow, col: nextCol });
      }.bind(this);

      if (piece.type === 'K') {
        for (let i = 0; i < ORTHOGONAL.length; i += 1) {
          const nextRow = row + ORTHOGONAL[i][0];
          const nextCol = col + ORTHOGONAL[i][1];
          if (inPalace(color, nextRow, nextCol)) add(nextRow, nextCol);
        }
        // 将帅照面时，可以沿空直线“飞将”吃子。
        const enemyGeneral = this.findGeneral(opposite(color));
        if (enemyGeneral && enemyGeneral.col === col &&
            this._clearBetween(row, col, enemyGeneral.row, enemyGeneral.col)) {
          moves.push({ row: enemyGeneral.row, col: enemyGeneral.col });
        }
        return moves;
      }

      if (piece.type === 'A') {
        for (let i = 0; i < DIAGONAL.length; i += 1) {
          const nextRow = row + DIAGONAL[i][0];
          const nextCol = col + DIAGONAL[i][1];
          if (inPalace(color, nextRow, nextCol)) add(nextRow, nextCol);
        }
        return moves;
      }

      if (piece.type === 'E') {
        for (let i = 0; i < ELEPHANT_MOVES.length; i += 1) {
          const nextRow = row + ELEPHANT_MOVES[i][0];
          const nextCol = col + ELEPHANT_MOVES[i][1];
          if (!inBounds(nextRow, nextCol)) continue;
          if (color === RED && nextRow < 5) continue;
          if (color === BLACK && nextRow > 4) continue;
          const eyeRow = row + ELEPHANT_MOVES[i][0] / 2;
          const eyeCol = col + ELEPHANT_MOVES[i][1] / 2;
          if (this.board[eyeRow][eyeCol]) continue;
          add(nextRow, nextCol);
        }
        return moves;
      }

      if (piece.type === 'H') {
        for (let i = 0; i < HORSE_MOVES.length; i += 1) {
          const move = HORSE_MOVES[i];
          const legRow = row + move[2];
          const legCol = col + move[3];
          if (!inBounds(legRow, legCol)) continue;
          if (this.board[legRow][legCol]) continue;
          add(row + move[0], col + move[1]);
        }
        return moves;
      }

      if (piece.type === 'R') {
        for (let i = 0; i < ORTHOGONAL.length; i += 1) {
          let nextRow = row + ORTHOGONAL[i][0];
          let nextCol = col + ORTHOGONAL[i][1];
          while (inBounds(nextRow, nextCol)) {
            const target = this.board[nextRow][nextCol];
            if (!target) {
              moves.push({ row: nextRow, col: nextCol });
            } else {
              if (target.color !== color) {
                moves.push({ row: nextRow, col: nextCol });
              }
              break;
            }
            nextRow += ORTHOGONAL[i][0];
            nextCol += ORTHOGONAL[i][1];
          }
        }
        return moves;
      }

      if (piece.type === 'C') {
        for (let i = 0; i < ORTHOGONAL.length; i += 1) {
          let nextRow = row + ORTHOGONAL[i][0];
          let nextCol = col + ORTHOGONAL[i][1];
          let screen = false;
          while (inBounds(nextRow, nextCol)) {
            const target = this.board[nextRow][nextCol];
            if (!screen) {
              if (!target) {
                moves.push({ row: nextRow, col: nextCol });
              } else {
                screen = true;
              }
            } else if (target) {
              if (target.color !== color) {
                moves.push({ row: nextRow, col: nextCol });
              }
              break;
            }
            nextRow += ORTHOGONAL[i][0];
            nextCol += ORTHOGONAL[i][1];
          }
        }
        return moves;
      }

      if (piece.type === 'P') {
        const forward = color === RED ? -1 : 1;
        add(row + forward, col);
        const crossedRiver = color === RED ? row <= 4 : row >= 5;
        if (crossedRiver) {
          add(row, col - 1);
          add(row, col + 1);
        }
        return moves;
      }

      return moves;
    }

    /*
     * 当前行棋方是否被将军。
     * 将帅照面也算将军；被牵制的棋子仍然“攻击”将帅所在格。
     */
    isInCheck(color) {
      const general = this.findGeneral(color);
      if (!general) return true;

      const enemy = opposite(color);
      const enemyGeneral = this.findGeneral(enemy);
      if (enemyGeneral && enemyGeneral.col === general.col &&
          this._clearBetween(general.row, general.col, enemyGeneral.row, enemyGeneral.col)) {
        return true;
      }

      for (let row = 0; row < ROWS; row += 1) {
        for (let col = 0; col < COLS; col += 1) {
          const piece = this.board[row][col];
          if (!piece || piece.color !== enemy) continue;
          const attacks = this._pseudoMovesFrom(row, col);
          for (let i = 0; i < attacks.length; i += 1) {
            if (attacks[i].row === general.row && attacks[i].col === general.col) {
              return true;
            }
          }
        }
      }
      return false;
    }

    /* 返回某枚棋子的全部合法落点（已经过滤送将/照面）。 */
    getLegalMovesFrom(row, col, color) {
      const piece = this.get(row, col);
      if (!piece) return [];
      if (color && piece.color !== color) return [];
      const pseudo = this._pseudoMovesFrom(row, col);
      const legal = [];

      for (let i = 0; i < pseudo.length; i += 1) {
        const target = this.board[pseudo[i].row][pseudo[i].col];
        this.board[row][col] = null;
        this.board[pseudo[i].row][pseudo[i].col] = piece;
        const unsafe = this.isInCheck(piece.color);
        this.board[row][col] = piece;
        this.board[pseudo[i].row][pseudo[i].col] = target;

        if (!unsafe) {
          legal.push({
            row: pseudo[i].row,
            col: pseudo[i].col,
            capture: target ? { type: target.type, color: target.color } : null
          });
        }
      }
      return legal;
    }

    hasLegalMove(row, col, color) {
      return this.getLegalMovesFrom(row, col, color).length > 0;
    }

    hasAnyLegalMove(color) {
      for (let row = 0; row < ROWS; row += 1) {
        for (let col = 0; col < COLS; col += 1) {
          const piece = this.board[row][col];
          if (!piece || piece.color !== color) continue;
          if (this.getLegalMovesFrom(row, col, color).length > 0) return true;
        }
      }
      return false;
    }

    getAllLegalMoves(color) {
      const moves = [];
      for (let row = 0; row < ROWS; row += 1) {
        for (let col = 0; col < COLS; col += 1) {
          const piece = this.board[row][col];
          if (!piece || piece.color !== color) continue;
          const pieceMoves = this.getLegalMovesFrom(row, col, color);
          for (let i = 0; i < pieceMoves.length; i += 1) {
            moves.push({
              from: { row: row, col: col },
              to: { row: pieceMoves[i].row, col: pieceMoves[i].col },
              piece: piece
            });
          }
        }
      }
      return moves;
    }

    isLegalMove(fromRow, fromCol, toRow, toCol, color) {
      const movingColor = color || this.turn;
      const piece = this.get(fromRow, fromCol);
      if (!piece || piece.color !== movingColor) return false;
      if (!inBounds(toRow, toCol)) return false;
      const moves = this.getLegalMovesFrom(fromRow, fromCol, movingColor);
      for (let i = 0; i < moves.length; i += 1) {
        if (moves[i].row === toRow && moves[i].col === toCol) return true;
      }
      return false;
    }

    /* 刷新将军与终局状态。 */
    refreshStatus() {
      this.check = this.isInCheck(this.turn);
      const general = this.findGeneral(this.turn);

      if (!general) {
        this.status = 'capture';
        this.winner = opposite(this.turn);
        this.endReason = 'capture';
        return this.status;
      }

      if (!this.hasAnyLegalMove(this.turn)) {
        if (this.check) {
          this.status = 'checkmate';
          this.endReason = 'checkmate';
        } else {
          this.status = 'stalemate';
          this.endReason = 'stalemate';
        }
        this.winner = opposite(this.turn);
        return this.status;
      }

      this.status = 'playing';
      this.winner = null;
      this.endReason = null;
      return this.status;
    }

    _fileNumber(color, col) {
      const number = color === RED ? COLS - col : col + 1;
      return color === RED ? CHINESE_NUMERALS[number - 1] : String(number);
    }

    _numberText(color, number) {
      return color === RED ? CHINESE_NUMERALS[number - 1] : String(number);
    }

    _duplicatePrefix(piece, fromRow, fromCol, board) {
      const allies = [];
      for (let row = 0; row < ROWS; row += 1) {
        const other = board[row] && board[row][fromCol];
        if (other && other.color === piece.color && other.type === piece.type) {
          allies.push(row);
        }
      }
      if (allies.length < 2) return '';

      allies.sort(function (a, b) {
        return piece.color === RED ? a - b : b - a;
      });
      const index = allies.indexOf(fromRow);
      if (index < 0) return '';

      let label;
      if (allies.length === 2) {
        label = index === 0 ? '前' : '后';
      } else if (allies.length === 3) {
        label = ['前', '中', '后'][index];
      } else {
        if (index === 0) label = '前';
        else if (index === allies.length - 1) label = '后';
        else label = this._numberText(piece.color, index + 1);
      }
      return label;
    }

    /* 生成中文棋谱记法，例如：炮二平五、马8进7。 */
    _buildNotation(piece, from, to, boardBefore) {
      const color = piece.color;
      const name = PIECE_NAMES[color][piece.type];
      const prefix = this._duplicatePrefix(piece, from.row, from.col, boardBefore);
      const lead = prefix ? prefix + name : name + this._fileNumber(color, from.col);

      let action;
      let tail;
      if (to.row === from.row) {
        action = '平';
        tail = this._fileNumber(color, to.col);
      } else {
        const forward = color === RED ? to.row < from.row : to.row > from.row;
        action = forward ? '进' : '退';
        if (piece.type === 'H' || piece.type === 'E' || piece.type === 'A') {
          tail = this._fileNumber(color, to.col);
        } else {
          tail = this._numberText(color, Math.abs(to.row - from.row));
        }
      }
      return lead + action + tail;
    }

    /**
     * 走一步棋。非法走法会抛出错误。
     * 返回这一步的棋谱记录。
     */
    makeMove(fromRow, fromCol, toRow, toCol) {
      if (this.status !== 'playing') {
        throw new Error('对局已经结束');
      }
      const piece = this.get(fromRow, fromCol);
      if (!piece) throw new Error('起点没有棋子');
      if (piece.color !== this.turn) throw new Error('还没轮到这一方');
      if (!this.isLegalMove(fromRow, fromCol, toRow, toCol, this.turn)) {
        throw new Error('不合法的走法');
      }

      const notation = this._buildNotation(piece, { row: fromRow, col: fromCol }, { row: toRow, col: toCol }, this.board);
      const captured = this.board[toRow][toCol];
      this.board[fromRow][fromCol] = null;
      this.board[toRow][toCol] = piece;
      this.turn = opposite(this.turn);

      const record = {
        from: { row: fromRow, col: fromCol },
        to: { row: toRow, col: toCol },
        piece: piece,
        captured: captured,
        color: piece.color,
        notation: notation,
        gaveCheck: false,
        endReason: null
      };
      this.history.push(record);
      this.lastMove = record;

      this.refreshStatus();
      record.gaveCheck = this.check;
      record.endReason = this.endReason;
      return record;
    }

    undo() {
      const record = this.history.pop();
      if (!record) return null;

      this.board[record.to.row][record.to.col] = record.captured || null;
      this.board[record.from.row][record.from.col] = record.piece;
      this.turn = record.piece.color;
      this.lastMove = this.history[this.history.length - 1] || null;
      this.refreshStatus();
      return record;
    }
  }

  return {
    Game: Game,
    ROWS: ROWS,
    COLS: COLS,
    RED: RED,
    BLACK: BLACK,
    START_POSITION: START_POSITION,
    PIECE_NAMES: PIECE_NAMES,
    PIECE_TITLES: PIECE_TITLES,
    opposite: opposite,
    inBounds: inBounds,
    inPalace: inPalace,
    pieceName: pieceName,
    colorName: colorName
  };
});
