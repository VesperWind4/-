# 参与贡献

感谢你愿意改进「楚河棋局」！这是一个无构建步骤、无运行时依赖的静态网页项目，参与门槛很低。

## 报告问题

提交 Issue 时，请尽量包含：

- 使用的浏览器和版本（如 Chrome 131、Safari 18）
- 操作系统与设备类型
- 复现步骤
- 预期结果与实际结果
- 控制台报错或截图（如果方便）

## 本地开发

项目不需要安装依赖或执行构建：

```bash
# 直接打开
# Windows: 双击 index.html
# macOS:   open index.html
# Linux:   xdg-open index.html

# 或者启动一个本地静态服务器
python -m http.server 8000
```

运行测试需要 Node.js 18 或更高版本：

```bash
npm test
# 等价于
node tests/rules.test.js
```

## 提交 Pull Request

1. Fork 仓库并从 `main` 创建分支。
2. 保持改动聚焦：一个 PR 尽量只解决一个问题。
3. 修改规则引擎时，请在 `tests/rules.test.js` 中补充对应测试。
4. 修改界面时，请检查桌面与窄屏布局，并尽量保留键盘可访问性。
5. 提交前运行 `npm test`。
6. 在 PR 描述中说明改动内容与验证方式。

## 代码约定

- 使用 2 个空格缩进，保留分号，文件使用 UTF-8 编码。
- `js/xiangqi.js` 必须保持无 DOM 依赖，以便在 Node.js 中直接测试。
- 不引入第三方运行时依赖；如需新增字体或图像资源，请先通过 Issue 讨论。
- 注释和用户界面文案以简体中文为主。

## 行为准则

请保持友善、就事论事。对代码的批评可以直接，但不要针对贡献者本人。

## 许可证

提交贡献即表示你同意以 [MIT License](LICENSE) 授权你的贡献。
