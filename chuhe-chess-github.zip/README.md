# 楚河棋局 · 双人中国象棋

一款无依赖、可离线运行的同屏双人中国象棋网页游戏。

[![MIT License](https://img.shields.io/badge/license-MIT-c9a96e.svg)](LICENSE)
![No dependencies](https://img.shields.io/badge/dependencies-0-2f6f4e.svg)
![Tests](https://img.shields.io/badge/tests-14%20passing-2f6f4e.svg)

![楚河棋局界面预览](assets/preview.jpg)

## 简介

「楚河棋局」使用原生 HTML、CSS 和 JavaScript 编写，不需要安装依赖、不需要构建，也不依赖任何后端服务。打开页面即可开始一局红黑双方共享同一块屏幕的中国象棋。

规则引擎与界面完全分离：`js/xiangqi.js` 不依赖 DOM，可以直接在 Node.js 中测试；`js/app.js` 负责棋盘绘制、交互、棋谱和音效。

## 功能

- **完整象棋规则**：马腿、象眼、炮架、过河兵、九宫限制、将帅照面、送将过滤
- **胜负判定**：绝杀、困毙、擒王，并自动弹出结果
- **同屏双人**：红方先行，双方轮流走子
- **合法落点**：点击棋子后显示全部可走位置，吃子位置显示红圈
- **中文棋谱**：按传统记法生成着法，如 `炮二平五`、`马8进7`
- **对局辅助**：悔棋、重新开局、吃子展示、最近一步高亮
- **响应式界面**：桌面、平板和手机均可对弈
- **音效与棋规**：内置轻量合成音效，可随时开关；棋规弹窗随时查看
- **键盘可访问**：棋盘支持方向键移动焦点，回车或空格选子落子
- **离线可用**：无外部字体、图片或运行时依赖

## 快速开始

直接双击 `index.html` 即可开始。

如果希望通过本地服务器访问：

```bash
python -m http.server 8000
```

然后打开 <http://127.0.0.1:8000>。

## 操作

| 操作 | 方式 |
| --- | --- |
| 选择棋子 | 点击或轻触己方棋子 |
| 确认落子 | 点击棋盘上的深色圆点 |
| 吃子 | 点击带红色圆圈的敌方棋子 |
| 悔棋 | 右侧「悔棋」按钮，或 `Ctrl/Cmd + Z` |
| 重新开局 | 右侧「重新开局」按钮 |
| 音效开关 | 右上角扬声器图标 |
| 查看棋规 | 右上角「棋规」按钮 |
| 键盘操作 | 方向键移动焦点，回车或空格确认 |

## 规则说明

- 红方先手，双方轮流走一着。
- 将死对方，或使对方无子可走（困毙），即获胜。
- 将帅不能在同一直线上直接照面；走子后己方被将军的着法会被禁止。
- 本作是休闲对局，未启用比赛规则中的长将、长捉等循环局面判罚。
- 当前版本为同屏双人，不包含 AI 对手或联网对战。

## 项目结构

```text
.
├── index.html                 页面结构
├── favicon.svg                站点图标
├── assets/
│   └── preview.jpg            界面预览
├── css/
│   └── style.css              视觉样式、棋盘纹理与响应式布局
├── js/
│   ├── xiangqi.js             无 DOM 依赖的象棋规则引擎
│   └── app.js                 棋盘渲染、交互、棋谱、音效与弹窗
├── tests/
│   └── rules.test.js          规则引擎自动化测试
├── .github/workflows/
│   ├── tests.yml              CI：在 Node 18 / 20 / 22 上运行测试
│   └── pages.yml              CD：自动发布到 GitHub Pages
├── CONTRIBUTING.md            贡献指南
├── LICENSE                    MIT 许可证
└── package.json               项目元数据与测试脚本
```

## 测试

需要 Node.js 18 或更高版本。项目没有第三方依赖，无需先执行 `npm install`：

```bash
npm test
```

等价于：

```bash
node tests/rules.test.js
```

测试覆盖初始局面走法、马腿、象眼、炮架、兵过河、九宫限制、将帅照面、
牵制、绝杀、困毙、中文棋谱与悔棋等关键规则。

## 部署到 GitHub Pages

仓库已经包含静态站点部署工作流：

1. 将代码推送到 GitHub 仓库的 `main` 分支。
2. 打开仓库的 **Settings → Pages**。
3. 将 **Build and deployment → Source** 设为 **GitHub Actions**。
4. 推送到 `main` 后，`Deploy to GitHub Pages` 工作流会自动发布页面。

发布地址通常为：

```text
https://<your-github-username>.github.io/chuhe-chess/
```

## 技术说明

- 零运行时依赖，纯原生 Web 技术实现。
- 规则引擎与 UI 解耦，便于编写单元测试或接入其他界面。
- 棋盘和棋子使用 SVG 与 CSS 绘制，音效由 Web Audio API 实时合成。
- 支持键盘操作、`prefers-reduced-motion` 和响应式布局。
- 建议使用最新版 Chrome、Edge、Firefox 或 Safari。

## 贡献

欢迎提交 Issue 和 Pull Request。请先阅读 [CONTRIBUTING.md](CONTRIBUTING.md)。

## 许可证

本项目基于 [MIT License](LICENSE) 开源。你可以自由使用、修改和分发，但请保留原始版权与许可证声明。
