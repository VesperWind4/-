'use strict';

const assert = require('node:assert/strict');
const X = require('../js/xiangqi.js');

const { Game, RED, BLACK } = X;

let passed = 0;

function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log('  ✓ ' + name);
  } catch (error) {
    console.error('  ✗ ' + name);
    throw error;
  }
}

function has(moves, row, col) {
  return moves.some((move) => move.row === row && move.col === col);
}

console.log('\n楚河棋局 · 规则引擎测试\n');

test('初始局面：32 枚棋子、红先、44 种合法走法', () => {
  const game = new Game();
  let pieces = 0;
  for (let row = 0; row < 10; row += 1) {
    for (let col = 0; col < 9; col += 1) {
      if (game.get(row, col)) pieces += 1;
    }
  }
  assert.equal(pieces, 32);
  assert.equal(game.turn, RED);
  assert.equal(game.status, 'playing');
  assert.equal(game.check, false);
  assert.equal(game.getAllLegalMoves(RED).length, 44);
  assert.equal(game.getAllLegalMoves(BLACK).length, 44);
});

test('马腿被挡时不能走“日”的对角', () => {
  const game = new Game({
    position: [
      '...k.....',
      '.........',
      '.........',
      '.........',
      '.........',
      '....H....',
      '.........',
      '.........',
      '.........',
      '....K....'
    ]
  });
  const moves = game.getLegalMovesFrom(5, 4, RED);
  assert.equal(has(moves, 3, 3), true);
  assert.equal(has(moves, 3, 5), true);

  const blocked = new Game({
    position: [
      '...k.....',
      '.........',
      '.........',
      '.........',
      '....P....',
      '....H....',
      '.........',
      '.........',
      '.........',
      '....K....'
    ]
  });
  const blockedMoves = blocked.getLegalMovesFrom(5, 4, RED);
  assert.equal(has(blockedMoves, 3, 3), false);
  assert.equal(has(blockedMoves, 3, 5), false);
  assert.equal(has(blockedMoves, 4, 2), true);
});

test('棋盘边缘的马不会越界报错', () => {
  const game = new Game();
  const moves = game.getLegalMovesFrom(0, 1, BLACK);
  assert.equal(has(moves, 2, 0), true);
  assert.equal(has(moves, 2, 2), true);
  assert.equal(moves.length, 2);
});

test('象不过河，且塞象眼不能走', () => {
  const game = new Game({
    position: [
      '...k.....',
      '.........',
      '.........',
      '.........',
      '.........',
      '..E......',
      '...P.....',
      '.........',
      '.........',
      '....K....'
    ]
  });
  const moves = game.getLegalMovesFrom(5, 2, RED);
  assert.equal(has(moves, 7, 0), true);
  assert.equal(has(moves, 7, 4), false, '象眼被塞');
  assert.equal(has(moves, 3, 0), false, '红象不能过河');
  assert.equal(has(moves, 3, 4), false, '红象不能过河');
});

test('炮吃子必须隔一个炮架', () => {
  const game = new Game({
    position: [
      '...k.....',
      'p........',
      'p........',
      '.........',
      '.........',
      'C........',
      '.........',
      '.........',
      '.........',
      '....K....'
    ]
  });
  const moves = game.getLegalMovesFrom(5, 0, RED);
  assert.equal(has(moves, 4, 0), true, '炮可以平移');
  assert.equal(has(moves, 3, 0), true, '炮可以走到炮架前');
  assert.equal(has(moves, 2, 0), false, '不能吃炮架');
  assert.equal(has(moves, 1, 0), true, '隔山打子');
  assert.equal(has(moves, 0, 0), false, '吃子后不能穿过目标');
  const capture = moves.find((move) => move.row === 1 && move.col === 0);
  assert.equal(capture.capture.color, BLACK);
});

test('兵过河前只能向前，过河后可左右', () => {
  const game = new Game({
    position: [
      '...k.....',
      '.........',
      '.........',
      '.........',
      '....P....',
      '.........',
      '....P....',
      '.........',
      '.........',
      '....K....'
    ]
  });
  const beforeRiver = game.getLegalMovesFrom(6, 4, RED);
  assert.deepEqual(beforeRiver.map((m) => [m.row, m.col]), [[5, 4]]);

  const afterRiver = game.getLegalMovesFrom(4, 4, RED);
  assert.equal(has(afterRiver, 3, 4), true);
  assert.equal(has(afterRiver, 4, 3), true);
  assert.equal(has(afterRiver, 4, 5), true);
  assert.equal(has(afterRiver, 5, 4), false, '兵不能后退');
});

test('士与将只能在九宫内行走，将帅不可照面', () => {
  const game = new Game({
    position: [
      '...k.....',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '....K....'
    ]
  });
  const generalMoves = game.getLegalMovesFrom(9, 4, RED);
  assert.equal(has(generalMoves, 8, 4), true);
  assert.equal(has(generalMoves, 9, 5), true);
  assert.equal(has(generalMoves, 9, 3), false, '走成将帅照面');
  assert.equal(generalMoves.every((m) => m.col >= 3 && m.col <= 5), true);
});

test('将帅照面时双方都算被将军', () => {
  const game = new Game({
    position: [
      '....k....',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '....K....'
    ]
  });
  assert.equal(game.isInCheck(RED), true);
  assert.equal(game.isInCheck(BLACK), true);
});

test('被牵制的棋子不能送将', () => {
  const game = new Game({
    position: [
      '...kr....',
      '.........',
      '.........',
      '.........',
      '.........',
      '....H....',
      '.........',
      '.........',
      '.........',
      '....K....'
    ]
  });
  assert.equal(game.isInCheck(RED), false);
  assert.equal(game.getLegalMovesFrom(5, 4, RED).length, 0, '马一动就暴露主帅');
});

test('绝杀：红车沉底肋道，黑将无路可走', () => {
  const game = new Game({
    position: [
      '....k....',
      'R.......R',
      '..H...H..',
      '.........',
      '.........',
      '....P....',
      '.........',
      '.........',
      '.........',
      '....K....'
    ]
  });
  assert.equal(game.status, 'playing');

  const record = game.makeMove(1, 0, 1, 4);
  assert.equal(record.notation, '车九平五');
  assert.equal(record.gaveCheck, true);
  assert.equal(record.endReason, 'checkmate');
  assert.equal(game.status, 'checkmate');
  assert.equal(game.winner, RED);
  assert.equal(game.check, true);
  assert.equal(game.turn, BLACK);

  const undone = game.undo();
  assert.equal(undone, record);
  assert.equal(game.status, 'playing');
  assert.equal(game.winner, null);
  assert.equal(game.turn, RED);
  assert.equal(game.history.length, 0);
  assert.equal(game.get(1, 0).type, 'R');
});

test('困毙：黑将未被将军但无子可走，判负', () => {
  const game = new Game({
    turn: BLACK,
    position: [
      '....k....',
      '...R.R...',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '.........',
      '...K.....'
    ]
  });
  assert.equal(game.check, false);
  assert.equal(game.status, 'stalemate');
  assert.equal(game.endReason, 'stalemate');
  assert.equal(game.winner, RED);
  assert.equal(game.hasAnyLegalMove(BLACK), false);
});

test('中文棋谱记法：红方中文数字，黑方阿拉伯数字', () => {
  const game = new Game();
  const red = game.makeMove(7, 1, 7, 4);
  assert.equal(red.notation, '炮八平五');
  assert.equal(red.gaveCheck, false);

  const black = game.makeMove(0, 1, 2, 2);
  assert.equal(black.notation, '马2进3');
  assert.equal(game.history.length, 2);
  assert.equal(game.turn, RED);

  game.undo();
  assert.equal(game.turn, BLACK);
  assert.equal(game.get(2, 2), null);
  assert.equal(game.get(0, 1).type, 'H');
});

test('非法走子会抛出错误', () => {
  const game = new Game();
  assert.throws(() => game.makeMove(0, 0, 1, 0), /还没轮到/);
  assert.throws(() => game.makeMove(9, 0, 8, 1), /不合法/);
  assert.throws(() => game.makeMove(7, 1, 2, 1), /不合法/, '炮不能直接吃子');
});

test('长将不自动判罚，但重复走法仍可正常记录', () => {
  const game = new Game();
  game.makeMove(7, 1, 7, 4);
  game.makeMove(0, 1, 2, 2);
  game.makeMove(7, 4, 7, 1);
  game.makeMove(2, 2, 0, 1);
  assert.equal(game.history.length, 4);
  assert.equal(game.turn, RED);
});

console.log('\n' + passed + ' 项测试全部通过。\n');
